<!DOCTYPE html>
<html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Piano di Studi - <?php echo e($corso->nome); ?></title>

        <!-- CSS Bootstrap & Icone -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap_v2.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap-icons/bootstrap-icons.css')); ?>">
        
        <!-- CSS Personalizzati -->
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/docente.css')); ?>">
    </head>
    <body class="min-vh-100" style="background-color: #e1edf7;">

        <!-- Script Bootstrap & Popper -->
        <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

        <!-- Navbar Istituzionale -->
        <nav class="navbar navbar-expand-lg bg-white shadow-sm border-bottom border-3 border-unibs py-2 mb-4">
            <div class="container-fluid px-3 px-md-5">
                
                <!-- Logo Università -->
                <a class="navbar-brand py-0" href="#">
                    <img class="img-logo" src="<?php echo e(asset('images/unibsLogo.png')); ?>" alt="Unibs" style="max-height: 70px;">
                </a>

                <!-- Toggler Mobile -->
                <button class="navbar-toggler border-0 shadow-none" 
                        type="button" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#navbarSupportedContent" 
                        aria-controls="navbarSupportedContent" 
                        aria-expanded="false" 
                        aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Menu di Navigazione -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto d-flex flex-row align-items-center gap-2 mt-3 mt-lg-0">
                        <li class="nav-item">
                            <a class="btn btn-unibs btn-sm text-white fw-bold px-3 py-1.5 rounded-pill shadow-sm d-inline-flex align-items-center justify-content-start" 
                               aria-current="page" 
                               href="<?php echo e(route('admin.dashboard')); ?>"
                               style="width: 115px;">
                                <i class="bi bi-house-door-fill text-center me-2" style="width: 18px;"></i>
                                <span>Home</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" 
                                        class="btn btn-danger btn-sm text-white fw-bold px-3 py-1.5 rounded-pill shadow-sm d-inline-flex align-items-center justify-content-start"
                                        style="width: 115px;">
                                    <i class="bi bi-box-arrow-right text-center me-2" style="width: 18px;"></i>
                                    <span>Logout</span>
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Contenuto Principale -->
        <div class="container py-3">

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm mb-4" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i><?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="d-flex align-items-center justify-content-between mb-4">
                <div>
                    <h1 class="h3 fw-bold text-unibs m-0 d-flex align-items-center">
                        <i class="bi bi-journal-bookmark-fill me-2"></i>Piano di Studi: <?php echo e($corso->nome); ?>

                    </h1>
                    <span class="badge border border-unibs text-unibs bg-transparent rounded-pill px-3 py-1.5 fw-bold mt-1"><?php echo e($corso->tipo_corso); ?></span>
                </div>
                <a href="<?php echo e(route('admin.corsi.index')); ?>" class="btn btn-unibs text-white fw-bold btn-sm rounded-pill px-3 shadow-sm">
                    <i class="bi bi-arrow-left me-1"></i>Torna ai Corsi
                </a>
            </div>
            <hr class="border-unibs border-2 opacity-100 mb-4">

            <!-- Pulsante Aggiungi Insegnamento al Corso -->
            <div class="mb-4">
                <a href="<?php echo e(route('admin.corsi.insegnamenti.create', $corso->corso_id)); ?>" class="btn btn-unibs text-white fw-bold w-100 py-2.5 rounded-3 shadow-sm d-flex align-items-center justify-content-center">
                    <i class="bi bi-plus-circle-fill me-2 fs-5"></i>Aggiungi insegnamenti al corso
                </a>
            </div>

            <!-- Anni del corso -->
            <?php for($anno = 1; $anno <= $durataAnni; $anno++): ?>
                <div class="card shadow-sm mb-4 border-0 rounded-3 overflow-hidden">
                    <div class="card-header bg-unibs text-white fw-bold py-2">
                        <i class="bi bi-calendar3 me-2"></i><?php echo e($anno); ?>° Anno di Corso
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush">
                            <?php $__empty_1 = true; $__currentLoopData = $insegnamentiPerAnno->get($anno, []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center py-3 px-4 <?php echo e($loop->even ? 'bg-light' : ''); ?>">
                                    <div>
                                        <strong class="fs-6 text-dark"><?php echo e($ic->insegnamento->nome ?? 'Insegnamento N/D'); ?></strong>
                                        <span class="text-muted d-block small">Codice: <?php echo e($ic->insegnamento_id); ?></span>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge border border-unibs text-unibs bg-transparent rounded-pill px-3 py-2 fw-bold me-1">
                                            <?php echo e($ic->cfu); ?> CFU
                                        </span>
                                        <span class="badge border border-unibs text-unibs bg-transparent rounded-pill px-3 py-2 fw-bold">
                                            <?php echo e($ic->durata); ?> ore
                                        </span>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted fst-italic py-3 px-4">
                                    Nessun insegnamento inserito per il <?php echo e($anno); ?>° anno.
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            <?php endfor; ?>
        </div>

    </body>
</html><?php /**PATH C:\xampp\htdocs\gestioneDate\gestioneDate\resources\views/admin/corsi/piano_di_studi.blade.php ENDPATH**/ ?>