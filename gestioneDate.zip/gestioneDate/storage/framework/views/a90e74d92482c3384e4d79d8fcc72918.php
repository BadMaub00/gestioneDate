<div>
    <!-- Life is available only in the present moment. - Thich Nhat Hanh -->
</div>
<?php /**PATH C:\xampp\htdocs\gestioneDate\gestioneDate\resources\views/admin/sessioni/index.blade.php ENDPATH**/ ?>